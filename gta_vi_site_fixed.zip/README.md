# GTA VI HUB

Главная страница сайта — `index.html`.

Для GitHub Pages:
Settings → Pages → Deploy from a branch → main → /(root).
